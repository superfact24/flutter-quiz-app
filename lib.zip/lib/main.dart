import 'package:adv_basics/quiz.dart';
import 'package:flutter/material.dart';

import 'package:adv_basics/start_screen.dart';

void main() {
  runApp(const Quiz());
}
